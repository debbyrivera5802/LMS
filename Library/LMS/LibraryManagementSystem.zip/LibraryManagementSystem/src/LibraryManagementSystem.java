import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
/*
 * Deborah Rivera, Software Development I, CEN 3024C, January 21 2024
	This LibraryManagementSystem class creates a Hashmap that takes in values based on user input.
	The user can add and remove books, or view the collection. The while loop allows the user to continue
	modifying the collection until they finish. Inside the if statements are methods to edit the collection.
 */
public class LibraryManagementSystem {
public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    HashMap<Integer, String > libraryCollection = new HashMap<>();
    Integer input=1;
    while(input != 3) {
        System.out.println("If you would like to add a book, type and enter 0");
        System.out.println("If you would like to remove a book, type and enter 1");
        System.out.println("If you would like to view the collection of books, type and enter 2");
        System.out.println("If you would like to finish, type and enter 3");
        input = scanner.nextInt();
        if (input == 0) {
            addItem(libraryCollection);
        }
        if (input == 1) {
            removeItem(libraryCollection);
        }
        if (input == 2) {
            displayCollection(libraryCollection);
        }

    }
}
public static void addItem(HashMap<Integer, String> collection) {
    /*
     * Add Item method creates two variables that hold the ID number of the book and the name of the book.
     * The methods getId() and getName() are called to get values from user input. Then once gathered
     * the collection is updated with the information. No values are returned.
     */
    int idNum;
    String name;
    //System.out.println("Please type in the ID of your book, the name, and the author.");
    Scanner scanner = new Scanner(System.in);
    idNum = getId();
    name = getName();
    //collection.add(scanner.nextLine());
    collection.put(idNum, name);
    return;
}


public static void displayCollection(HashMap<Integer, String> collection ) {
    /*
     * The Display Collection method takes in the Hashmap and displays it. Nothing is returned.
     */
    for (int i : collection.keySet()) {
        System.out.print(i + ", ");
        System.out.println(collection.get(i));
    }
    return;
}

public static void removeItem(HashMap<Integer, String> collection) {
    /*
     * The Remove Item method asks for the user to input the ID and removes the corresponding book with
     * that ID using the .remove method for the Hashmap.
     */
    Scanner scanner = new Scanner(System.in);
    System.out.println("Please type in the ID of the book you would like to remove");
    int bookID = scanner.nextInt();
    collection.remove(bookID);

}

public static int getId() {
    /*
     * The getID method gets the book ID with user input. The integer is returned.
     */
    Scanner scanner = new Scanner(System.in);
    System.out.println("Enter the ID number...");
    int id = scanner.nextInt();
    return id;
}
public static String getName() {
    /*
     * The getName method gets the name and author with user input. The integer is returned.
     */
    Scanner scanner = new Scanner(System.in);
    System.out.println("Enter the name and author seperated by commas...");
    String author = scanner.nextLine();
    return author;
}
	}

